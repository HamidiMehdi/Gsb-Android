<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // mf_web_service_connexion
        if (0 === strpos($pathinfo, '/Connexion') && preg_match('#^/Connexion/(?P<matricule>[^/]++)/(?P<mdp>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'mf_web_service_connexion')), array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::connexionAction',));
        }

        // mf_web_service_rv_mois_annee
        if (0 === strpos($pathinfo, '/RapportVisite') && preg_match('#^/RapportVisite/(?P<matricule>[^/]++)/(?P<mois>[^/]++)/(?P<annee>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'mf_web_service_rv_mois_annee')), array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::getRapportVisiteAction',));
        }

        // mf_web_service_rv_rapport_lu
        if (0 === strpos($pathinfo, '/UpdateRapport') && preg_match('#^/UpdateRapport/(?P<numero>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'mf_web_service_rv_rapport_lu')), array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::updateRapportLuAction',));
        }

        // mf_web_service_rv_echantillons
        if (0 === strpos($pathinfo, '/Echantillons') && preg_match('#^/Echantillons/(?P<numero>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'mf_web_service_rv_echantillons')), array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::getEchantillonsAction',));
        }

        // mf_web_service_rv_motifs
        if ($pathinfo === '/Motifs') {
            return array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::getMotifsAction',  '_route' => 'mf_web_service_rv_motifs',);
        }

        // mf_web_service_rv_praticiens
        if ($pathinfo === '/Praticiens') {
            return array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::getPraticiensAction',  '_route' => 'mf_web_service_rv_praticiens',);
        }

        // mf_web_service_rv_medicaments
        if ($pathinfo === '/Medicaments') {
            return array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::getMedicamentAction',  '_route' => 'mf_web_service_rv_medicaments',);
        }

        // mf_web_service_rv_nouveau_rapport
        if (0 === strpos($pathinfo, '/NewRapport') && preg_match('#^/NewRapport/(?P<matricule>[^/]++)/(?P<numPraticien>[^/]++)/(?P<bilan>[^/]++)/(?P<numMotif>[^/]++)/(?P<coefconf>[^/]++)/(?P<dateVisite>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'mf_web_service_rv_nouveau_rapport')), array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::nouveauRapportAction',));
        }

        // mf_web_service_rv_ajouter_echantillons
        if (0 === strpos($pathinfo, '/AjouterEchant') && preg_match('#^/AjouterEchant/(?P<matricule>[^/]++)/(?P<numRapport>[^/]++)/(?P<echant>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'mf_web_service_rv_ajouter_echantillons')), array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::ajouterEchantAction',));
        }

        // mf_web_service_rv_modifier_mdp
        if (0 === strpos($pathinfo, '/ModifierMdp') && preg_match('#^/ModifierMdp/(?P<matricule>[^/]++)/(?P<mdp>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'mf_web_service_rv_modifier_mdp')), array (  '_controller' => 'MF\\WebServiceBundle\\Controller\\DefaultController::changerMdpAction',));
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
