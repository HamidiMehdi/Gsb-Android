<?php

/* MFWebServiceBundle:Default:index.html.twig */
class __TwigTemplate_e181389ff27298aea0f93118b573f53e788da579eb52f0f2a078c74e597004b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc60f2db6e6c65943a3da701cdff394ddf761894bce8255c3be61940370d5f15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc60f2db6e6c65943a3da701cdff394ddf761894bce8255c3be61940370d5f15->enter($__internal_cc60f2db6e6c65943a3da701cdff394ddf761894bce8255c3be61940370d5f15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MFWebServiceBundle:Default:index.html.twig"));

        // line 1
        echo "Hello ";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "!
";
        
        $__internal_cc60f2db6e6c65943a3da701cdff394ddf761894bce8255c3be61940370d5f15->leave($__internal_cc60f2db6e6c65943a3da701cdff394ddf761894bce8255c3be61940370d5f15_prof);

    }

    public function getTemplateName()
    {
        return "MFWebServiceBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello {{ name }}!
", "MFWebServiceBundle:Default:index.html.twig", "/var/www/ServeurWebService/src/MF/WebServiceBundle/Resources/views/Default/index.html.twig");
    }
}
