<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_9bc87229811b3f655d855c430ddaee33f5c67c0976b34d477b6489ce132cdf32 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d922466ac0e70e929139eca3681120b0dc7c34e4e2925f5300762bbf905dc4e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d922466ac0e70e929139eca3681120b0dc7c34e4e2925f5300762bbf905dc4e7->enter($__internal_d922466ac0e70e929139eca3681120b0dc7c34e4e2925f5300762bbf905dc4e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_d922466ac0e70e929139eca3681120b0dc7c34e4e2925f5300762bbf905dc4e7->leave($__internal_d922466ac0e70e929139eca3681120b0dc7c34e4e2925f5300762bbf905dc4e7_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_eeec1772465d911f063def2bc286c1dbf9259882c2cdcb28c3e04bb7b6303204 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eeec1772465d911f063def2bc286c1dbf9259882c2cdcb28c3e04bb7b6303204->enter($__internal_eeec1772465d911f063def2bc286c1dbf9259882c2cdcb28c3e04bb7b6303204_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_eeec1772465d911f063def2bc286c1dbf9259882c2cdcb28c3e04bb7b6303204->leave($__internal_eeec1772465d911f063def2bc286c1dbf9259882c2cdcb28c3e04bb7b6303204_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/var/www/ServeurWebService/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
