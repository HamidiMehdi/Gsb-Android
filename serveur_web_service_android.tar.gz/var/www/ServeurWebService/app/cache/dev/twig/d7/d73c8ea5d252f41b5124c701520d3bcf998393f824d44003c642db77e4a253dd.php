<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_f12daab6d224d6edd97f3ce7dcfc1b38974717b3f851f21504e688dc6bfca36d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58c40f7ff1190fcf8017e9fcd3b5c5dc38bf5a1578c7b153d374ddf8c7574442 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58c40f7ff1190fcf8017e9fcd3b5c5dc38bf5a1578c7b153d374ddf8c7574442->enter($__internal_58c40f7ff1190fcf8017e9fcd3b5c5dc38bf5a1578c7b153d374ddf8c7574442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_58c40f7ff1190fcf8017e9fcd3b5c5dc38bf5a1578c7b153d374ddf8c7574442->leave($__internal_58c40f7ff1190fcf8017e9fcd3b5c5dc38bf5a1578c7b153d374ddf8c7574442_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include 'TwigBundle:Exception:error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/var/www/ServeurWebService/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
