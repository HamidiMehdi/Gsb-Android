<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_95c8b31cb89687a088b223452db5d1c93f9b7390c5282e807e3bb565d2dd5285 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8ad68910b787089ad6c58ffe0fd4dd25b8c69a543cb4829764bab0e1b5b1907 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8ad68910b787089ad6c58ffe0fd4dd25b8c69a543cb4829764bab0e1b5b1907->enter($__internal_e8ad68910b787089ad6c58ffe0fd4dd25b8c69a543cb4829764bab0e1b5b1907_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_e8ad68910b787089ad6c58ffe0fd4dd25b8c69a543cb4829764bab0e1b5b1907->leave($__internal_e8ad68910b787089ad6c58ffe0fd4dd25b8c69a543cb4829764bab0e1b5b1907_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include 'TwigBundle:Exception:error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/var/www/ServeurWebService/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
