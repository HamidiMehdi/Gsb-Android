<?php

namespace MF\WebServiceBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use MF\WebServiceBundle\Entity\RapportVisite;
use MF\WebServiceBundle\Entity\Offrir;

class DefaultController extends Controller
{
    
    public function connexionAction($matricule, $mdp)
    {
        
        $em = $this->getDoctrine()->getManager();
        $repository_visiteur = $em->getRepository('MFWebServiceBundle:Visiteur');
        $visiteur = $repository_visiteur->findOneBy(array('visMatricule' => $matricule,
                'visMdp' => $mdp));
        
        if($visiteur != null ){ // si le visiteur exist
            $tab = array('existe' => true, 'matricule' => $visiteur->getVisMatricule(), 
                'mdp' => $visiteur->getVisMdp(), 'nom' => $visiteur->getVisNom(), 
                'prenom' => $visiteur->getVisPrenom());
            
            $date_courante = date('Y-m-d');
            $visiteur->setVisDernierconnexion(date_create($date_courante));
            $em->persist($visiteur);
            $em->flush();
        }
        else {
            $tab = array('existe' => false);
        }
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
    }
    
    
    public function getRapportVisiteAction($matricule, $mois, $annee)
    {
        $em = $this->getDoctrine()->getManager() ;
        
        $visiteur_repository = $em->getRepository('MFWebServiceBundle:Visiteur');
        $visiteur = $visiteur_repository->findOneBy(array('visMatricule' => $matricule));
        
        $rv_repository = $em->getRepository('MFWebServiceBundle:RapportVisite');
        $rvs = $rv_repository->findBy(array('visMatricule' => $visiteur), array('rapDateVisite' => 'desc'));
        
        $rapportVisites = array();
        
        foreach($rvs as $unRv){
            $anneeRv = $unRv->getRapDateVisite()->format('Y');
            $moisRv = $unRv->getRapDateVisite()->format('m');
            
                if($anneeRv == $annee){ // si il correspond a l'année
                    if($moisRv == $mois){ // si il correspond au mois
                        array_push($rapportVisites, $unRv);
                    }
                }
        }
        
        $tab = array();
        
        if($rapportVisites != null){
            foreach($rapportVisites as $unRapportVisite){
                $tab[] = array(
                    'numero' => $unRapportVisite->getRapNum(),
                    'bilan' => $unRapportVisite->getRapBilan(),
                    'coefConfiance' => $unRapportVisite->getRapCoefconfiance(),
                    'dateVisite' => $unRapportVisite->getRapDateVisite()->format('Y-m-d'),
                    'dateRedaction' => $unRapportVisite->getRapDateCreation()->format('Y-m-d'),
                    'lu' => $unRapportVisite->getRapEstLu(),
                    'praticien' => array(
                                        'numero' => $unRapportVisite->getPraNum()->getPraNum(),
                                        'nom' => $unRapportVisite->getPraNum()->getPraNom(),
                                        'prenom' => $unRapportVisite->getPraNum()->getPraPrenom()
                                        ),
                    'motif' => array(
                                    'code' => $unRapportVisite->getMotifNum()->getMotifNum(),
                                    'libelle' => $unRapportVisite->getMotifNum()->getMotifLibelle()
                                    )
                );
            }
        }
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
        
    }
    
    public function updateRapportLuAction($numero)
    {
        $em = $this->getDoctrine()->getManager() ;
        
        $visiteur_repository = $em->getRepository('MFWebServiceBundle:Visiteur');
        $visiteur = $visiteur_repository->findOneBy(array('visMatricule' => 'a131'));
        
        $rv_repository = $em->getRepository('MFWebServiceBundle:RapportVisite');
        $rv = $rv_repository->findOneBy(array('rapNum' => $numero));
        
        $rv->setRapEstLu(True);
        $em->persist($rv);
        $em->flush();
        
        $tab = array('modifier' => true);
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
        
        
    }
    
    public function getEchantillonsAction($numero){
        
        $em = $this->getDoctrine()->getManager() ;
        
        $offrir_repository = $em->getRepository('MFWebServiceBundle:Offrir');
        $offrir = $offrir_repository->findBy(array('rapNum' => $numero));
        
        $tab = array();
        
        if($offrir != null){
            foreach($offrir as $unOffrir){
                $tab[] = array(
                                'medicament' => array(
                                            'depotLegal' => $unOffrir->getMedDepotlegal()->getMedDepotlegal() ,
                                            'nomCommercial' => $unOffrir->getMedDepotlegal()->getMedNomcommercial()
                                            ),
                                'quantite' => $unOffrir->getOffQte()
                        );
            }
        }
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
        
    }
    
    
    public function getMotifsAction()
    {
        $em = $this->getDoctrine()->getManager() ;
        
        $repository_motif = $em->getRepository('MFWebServiceBundle:Motif');
        $motifs = $repository_motif->findAll();
        
        $tab = array();

        foreach($motifs as $unMotif) {
             $tab[] = array(
                 'code' => $unMotif->getMotifNum(),
                 'libelle' => $unMotif->getMotifLibelle()
             );
        }
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
    }
    
    public function getPraticiensAction()
    {
        $em = $this->getDoctrine()->getManager() ;
        
        $repository_Praticien = $em->getRepository('MFWebServiceBundle:Praticien');
        $praticiens = $repository_Praticien->findAll();
        
        $tab = array();

        foreach($praticiens as $unPraticiens) {
             $tab[] = array(
                 'numero' => $unPraticiens->getPraNum(),
                 'nom' => $unPraticiens->getPraNom(),
                 'prenom' => $unPraticiens->getPraPrenom()
             );
        }
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
    }
    
    public function getMedicamentAction()
    {
        $em = $this->getDoctrine()->getManager() ;
        
        $repository_medicament = $em->getRepository('MFWebServiceBundle:Medicament');
        $medicaments = $repository_medicament->findAll();
        
        $tab = array();

        foreach($medicaments as $unMedicament) {
             $tab[] = array(
                 'depotLegal' => $unMedicament->getMedDepotlegal(),
                 'nomCommercial' => $unMedicament->getMedNomcommercial()
             );
        }
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
    }
    
    public function nouveauRapportAction($matricule, $numPraticien, $bilan, $numMotif, $coefconf, $dateVisite)
    {
        $em = $this->getDoctrine()->getManager();
        
        $repository_visiteur = $em->getRepository('MFWebServiceBundle:Visiteur');
        $visiteur = $repository_visiteur->findOneBy(array('visMatricule' => $matricule));
        
        $repository_praticien = $em->getRepository('MFWebServiceBundle:Praticien');
        $praticien = $repository_praticien->find($numPraticien);
        
        $repositoy_motif = $em->getRepository('MFWebServiceBundle:Motif');
        $motif = $repositoy_motif->find($numMotif);
        
        $bilanFini = "";
        $tabBilan = explode("|", $bilan);
        $dernierLigne = count($tabBilan) -1 ;
        $i =0;
        for($i; $i < count($tabBilan); $i++){
            if($i == $dernierLigne){
                $bilanFini = $bilanFini.$tabBilan[$i] ;
            }
            else{
                $bilanFini = $bilanFini.$tabBilan[$i]." " ;
            }
        }
        
        
        $rv = new RapportVisite();
        $rv->setRapBilan($bilanFini);
        $rv->setRapCoefconfiance($coefconf);
        $rv->setRapDateVisite(date_create(date($dateVisite)));
        $rv->setRapDateCreation(date_create(date('Y-m-d')));
        $rv->setRapEstLu(false);
        $rv->setMotifNum($motif);
        $rv->setPraNum($praticien);
        $rv->setVisMatricule($visiteur);
        
        $em->persist($rv);
        $em->flush();
        
        $tab = array('rap_num' => $rv->getRapNum());
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
        
        
    }
    
    public function ajouterEchantAction($matricule, $numRapport, $echant)
    {
        $em = $this->getDoctrine()->getManager();
        
        $echant = explode("|", $echant);
        foreach($echant as $unEchant){
            $echantDonnee = explode(";", $unEchant);
            
            if($echantDonnee[1] > 0){
                
                $repository_medicament = $em->getRepository('MFWebServiceBundle:Medicament');
                $medicament = $repository_medicament->findOneBy(array('medDepotlegal' => $echantDonnee[0] ));
                
                $offrir = new Offrir();
                $offrir->setVisMatricule($matricule);
                $offrir->setRapNum($numRapport);
                $offrir->setMedDepotlegal($medicament);
                $offrir->setOffQte($echantDonnee[1]);

                $em->persist($offrir);
            }
        }
        $em->flush();
        
        $tab = array('insertion' => true);
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
        
    }

    public function changerMdpAction($matricule, $mdp)
    {
        $em = $this->getDoctrine()->getManager();
        $repository_visiteur = $em->getRepository('MFWebServiceBundle:Visiteur');
        $visiteur = $repository_visiteur->findOneBy(array('visMatricule' => $matricule));
        
        $visiteur->setVisMdp($mdp);
        $em->persist($visiteur);
        $em->flush();
        
        $tab = array('modificationMDP' => true);
        
        $reponse = new JsonResponse();
        $reponse->headers->set('Content-Type', 'text/plain');
        $reponse->setCharset("utf-8");
        $reponse->setEncodingOptions(JSON_UNESCAPED_UNICODE);
        $reponse->setData($tab);
        $reponse->setStatusCode(200);
       
        return $reponse;
    }
    
}
