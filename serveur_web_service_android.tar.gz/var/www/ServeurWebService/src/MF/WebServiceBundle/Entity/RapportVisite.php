<?php

namespace MF\WebServiceBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RapportVisite
 *
 * @ORM\Table(name="RAPPORT_VISITE", indexes={@ORM\Index(name="FK_RAPPORT_VISITE_PRATICIEN", columns={"PRA_NUM"}), @ORM\Index(name="FK_RAPPORT_VISITE_VISITEUR", columns={"VIS_MATRICULE"}), @ORM\Index(name="FK_RAPPORT_VISITE_MOTIF", columns={"MOTIF_NUM"})})
 * @ORM\Entity(repositoryClass="MF\WebServiceBundle\Entity\RapportVisiteRepository")
 */
class RapportVisite
{
    /**
     * @var integer
     *
     * @ORM\Column(name="RAP_NUM", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $rapNum;

    /**
     * @var string
     *
     * @ORM\Column(name="RAP_BILAN", type="string", length=510, nullable=false)
     */
    private $rapBilan;

    /**
     * @var string
     *
     * @ORM\Column(name="RAP_COEFCONFIANCE", type="string", length=300, nullable=false)
     */
    private $rapCoefconfiance;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="RAP_DATE_VISITE", type="date", nullable=false)
     */
    private $rapDateVisite;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="RAP_DATE_CREATION", type="date", nullable=false)
     */
    private $rapDateCreation;

    /**
     * @var boolean
     *
     * @ORM\Column(name="RAP_EST_LU", type="boolean", nullable=false)
     */
    private $rapEstLu;

    /**
     * @var \Motif
     *
     * @ORM\ManyToOne(targetEntity="Motif")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="MOTIF_NUM", referencedColumnName="MOTIF_NUM")
     * })
     */
    private $motifNum;

    /**
     * @var \Praticien
     *
     * @ORM\ManyToOne(targetEntity="Praticien")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="PRA_NUM", referencedColumnName="PRA_NUM")
     * })
     */
    private $praNum;

    /**
     * @var \Visiteur
     *
     * @ORM\ManyToOne(targetEntity="Visiteur")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="VIS_MATRICULE", referencedColumnName="VIS_MATRICULE")
     * })
     */
    private $visMatricule;



    /**
     * Get rapNum
     *
     * @return integer 
     */
    public function getRapNum()
    {
        return $this->rapNum;
    }

    /**
     * Set rapBilan
     *
     * @param string $rapBilan
     * @return RapportVisite
     */
    public function setRapBilan($rapBilan)
    {
        $this->rapBilan = $rapBilan;

        return $this;
    }

    /**
     * Get rapBilan
     *
     * @return string 
     */
    public function getRapBilan()
    {
        return $this->rapBilan;
    }

    /**
     * Set rapCoefconfiance
     *
     * @param string $rapCoefconfiance
     * @return RapportVisite
     */
    public function setRapCoefconfiance($rapCoefconfiance)
    {
        $this->rapCoefconfiance = $rapCoefconfiance;

        return $this;
    }

    /**
     * Get rapCoefconfiance
     *
     * @return string 
     */
    public function getRapCoefconfiance()
    {
        return $this->rapCoefconfiance;
    }

    /**
     * Set rapDateVisite
     *
     * @param \DateTime $rapDateVisite
     * @return RapportVisite
     */
    public function setRapDateVisite($rapDateVisite)
    {
        $this->rapDateVisite = $rapDateVisite;

        return $this;
    }

    /**
     * Get rapDateVisite
     *
     * @return \DateTime 
     */
    public function getRapDateVisite()
    {
        return $this->rapDateVisite;
    }

    /**
     * Set rapDateCreation
     *
     * @param \DateTime $rapDateCreation
     * @return RapportVisite
     */
    public function setRapDateCreation($rapDateCreation)
    {
        $this->rapDateCreation = $rapDateCreation;

        return $this;
    }

    /**
     * Get rapDateCreation
     *
     * @return \DateTime 
     */
    public function getRapDateCreation()
    {
        return $this->rapDateCreation;
    }

    /**
     * Set rapEstLu
     *
     * @param boolean $rapEstLu
     * @return RapportVisite
     */
    public function setRapEstLu($rapEstLu)
    {
        $this->rapEstLu = $rapEstLu;

        return $this;
    }

    /**
     * Get rapEstLu
     *
     * @return boolean 
     */
    public function getRapEstLu()
    {
        return $this->rapEstLu;
    }

    /**
     * Set motifNum
     *
     * @param \MF\WebServiceBundle\Entity\Motif $motifNum
     * @return RapportVisite
     */
    public function setMotifNum(\MF\WebServiceBundle\Entity\Motif $motifNum = null)
    {
        $this->motifNum = $motifNum;

        return $this;
    }

    /**
     * Get motifNum
     *
     * @return \MF\WebServiceBundle\Entity\Motif 
     */
    public function getMotifNum()
    {
        return $this->motifNum;
    }

    /**
     * Set praNum
     *
     * @param \MF\WebServiceBundle\Entity\Praticien $praNum
     * @return RapportVisite
     */
    public function setPraNum(\MF\WebServiceBundle\Entity\Praticien $praNum = null)
    {
        $this->praNum = $praNum;

        return $this;
    }

    /**
     * Get praNum
     *
     * @return \MF\WebServiceBundle\Entity\Praticien 
     */
    public function getPraNum()
    {
        return $this->praNum;
    }

    /**
     * Set visMatricule
     *
     * @param \MF\WebServiceBundle\Entity\Visiteur $visMatricule
     * @return RapportVisite
     */
    public function setVisMatricule(\MF\WebServiceBundle\Entity\Visiteur $visMatricule = null)
    {
        $this->visMatricule = $visMatricule;

        return $this;
    }

    /**
     * Get visMatricule
     *
     * @return \MF\WebServiceBundle\Entity\Visiteur 
     */
    public function getVisMatricule()
    {
        return $this->visMatricule;
    }
}
