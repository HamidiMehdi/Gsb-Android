<?php

namespace MF\WebServiceBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Travailler
 *
 * @ORM\Table(name="TRAVAILLER", indexes={@ORM\Index(name="FK_TRAVAILLER_REGION", columns={"REG_CODE"}), @ORM\Index(name="IDX_9B2DC20212EB9372", columns={"VIS_MATRICULE"})})
 * @ORM\Entity(repositoryClass="MF\WebServiceBundle\Entity\TravaillerRepository")
 */
class Travailler
{
    /**
     * @var \DateTime
     *
     * @ORM\Column(name="JJMMAA", type="date", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $jjmmaa;

    /**
     * @var string
     *
     * @ORM\Column(name="TRA_ROLE", type="string", length=22, nullable=true)
     */
    private $traRole;

    /**
     * @var \Region
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Region")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="REG_CODE", referencedColumnName="REG_CODE")
     * })
     */
    private $regCode;

    /**
     * @var \Visiteur
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Visiteur")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="VIS_MATRICULE", referencedColumnName="VIS_MATRICULE")
     * })
     */
    private $visMatricule;



    /**
     * Set jjmmaa
     *
     * @param \DateTime $jjmmaa
     * @return Travailler
     */
    public function setJjmmaa($jjmmaa)
    {
        $this->jjmmaa = $jjmmaa;

        return $this;
    }

    /**
     * Get jjmmaa
     *
     * @return \DateTime 
     */
    public function getJjmmaa()
    {
        return $this->jjmmaa;
    }

    /**
     * Set traRole
     *
     * @param string $traRole
     * @return Travailler
     */
    public function setTraRole($traRole)
    {
        $this->traRole = $traRole;

        return $this;
    }

    /**
     * Get traRole
     *
     * @return string 
     */
    public function getTraRole()
    {
        return $this->traRole;
    }

    /**
     * Set regCode
     *
     * @param \MF\WebServiceBundle\Entity\Region $regCode
     * @return Travailler
     */
    public function setRegCode(\MF\WebServiceBundle\Entity\Region $regCode)
    {
        $this->regCode = $regCode;

        return $this;
    }

    /**
     * Get regCode
     *
     * @return \MF\WebServiceBundle\Entity\Region 
     */
    public function getRegCode()
    {
        return $this->regCode;
    }

    /**
     * Set visMatricule
     *
     * @param \MF\WebServiceBundle\Entity\Visiteur $visMatricule
     * @return Travailler
     */
    public function setVisMatricule(\MF\WebServiceBundle\Entity\Visiteur $visMatricule)
    {
        $this->visMatricule = $visMatricule;

        return $this;
    }

    /**
     * Get visMatricule
     *
     * @return \MF\WebServiceBundle\Entity\Visiteur 
     */
    public function getVisMatricule()
    {
        return $this->visMatricule;
    }
}
