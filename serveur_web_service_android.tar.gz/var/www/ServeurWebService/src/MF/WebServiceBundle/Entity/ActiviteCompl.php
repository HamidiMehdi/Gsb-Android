<?php

namespace MF\WebServiceBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ActiviteCompl
 *
 * @ORM\Table(name="ACTIVITE_COMPL")
 * @ORM\Entity(repositoryClass="MF\WebServiceBundle\Entity\ActiviteComplRepository")
 */
class ActiviteCompl
{
    /**
     * @var integer
     *
     * @ORM\Column(name="AC_NUM", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $acNum;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="AC_DATE", type="date", nullable=true)
     */
    private $acDate;

    /**
     * @var string
     *
     * @ORM\Column(name="AC_LIEU", type="string", length=50, nullable=true)
     */
    private $acLieu;

    /**
     * @var string
     *
     * @ORM\Column(name="AC_THEME", type="string", length=20, nullable=true)
     */
    private $acTheme;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Praticien", inversedBy="acNum")
     * @ORM\JoinTable(name="inviter",
     *   joinColumns={
     *     @ORM\JoinColumn(name="AC_NUM", referencedColumnName="AC_NUM")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="PRA_NUM", referencedColumnName="PRA_NUM")
     *   }
     * )
     */
    private $praNum;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Visiteur", inversedBy="acNum")
     * @ORM\JoinTable(name="realiser",
     *   joinColumns={
     *     @ORM\JoinColumn(name="AC_NUM", referencedColumnName="AC_NUM")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="VIS_MATRICULE", referencedColumnName="VIS_MATRICULE")
     *   }
     * )
     */
    private $visMatricule;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->praNum = new \Doctrine\Common\Collections\ArrayCollection();
        $this->visMatricule = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Get acNum
     *
     * @return integer 
     */
    public function getAcNum()
    {
        return $this->acNum;
    }

    /**
     * Set acDate
     *
     * @param \DateTime $acDate
     * @return ActiviteCompl
     */
    public function setAcDate($acDate)
    {
        $this->acDate = $acDate;

        return $this;
    }

    /**
     * Get acDate
     *
     * @return \DateTime 
     */
    public function getAcDate()
    {
        return $this->acDate;
    }

    /**
     * Set acLieu
     *
     * @param string $acLieu
     * @return ActiviteCompl
     */
    public function setAcLieu($acLieu)
    {
        $this->acLieu = $acLieu;

        return $this;
    }

    /**
     * Get acLieu
     *
     * @return string 
     */
    public function getAcLieu()
    {
        return $this->acLieu;
    }

    /**
     * Set acTheme
     *
     * @param string $acTheme
     * @return ActiviteCompl
     */
    public function setAcTheme($acTheme)
    {
        $this->acTheme = $acTheme;

        return $this;
    }

    /**
     * Get acTheme
     *
     * @return string 
     */
    public function getAcTheme()
    {
        return $this->acTheme;
    }

    /**
     * Add praNum
     *
     * @param \MF\WebServiceBundle\Entity\Praticien $praNum
     * @return ActiviteCompl
     */
    public function addPraNum(\MF\WebServiceBundle\Entity\Praticien $praNum)
    {
        $this->praNum[] = $praNum;

        return $this;
    }

    /**
     * Remove praNum
     *
     * @param \MF\WebServiceBundle\Entity\Praticien $praNum
     */
    public function removePraNum(\MF\WebServiceBundle\Entity\Praticien $praNum)
    {
        $this->praNum->removeElement($praNum);
    }

    /**
     * Get praNum
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPraNum()
    {
        return $this->praNum;
    }

    /**
     * Add visMatricule
     *
     * @param \MF\WebServiceBundle\Entity\Visiteur $visMatricule
     * @return ActiviteCompl
     */
    public function addVisMatricule(\MF\WebServiceBundle\Entity\Visiteur $visMatricule)
    {
        $this->visMatricule[] = $visMatricule;

        return $this;
    }

    /**
     * Remove visMatricule
     *
     * @param \MF\WebServiceBundle\Entity\Visiteur $visMatricule
     */
    public function removeVisMatricule(\MF\WebServiceBundle\Entity\Visiteur $visMatricule)
    {
        $this->visMatricule->removeElement($visMatricule);
    }

    /**
     * Get visMatricule
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getVisMatricule()
    {
        return $this->visMatricule;
    }
}
