<?php

namespace MF\WebServiceBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Motif
 *
 * @ORM\Table(name="MOTIF")
 * @ORM\Entity(repositoryClass="MF\WebServiceBundle\Entity\MotifRepository")
 */
class Motif
{
    /**
     * @var integer
     *
     * @ORM\Column(name="MOTIF_NUM", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $motifNum;

    /**
     * @var string
     *
     * @ORM\Column(name="MOTIF_LIBELLE", type="string", length=150, nullable=false)
     */
    private $motifLibelle;



    /**
     * Get motifNum
     *
     * @return integer 
     */
    public function getMotifNum()
    {
        return $this->motifNum;
    }

    /**
     * Set motifLibelle
     *
     * @param string $motifLibelle
     * @return Motif
     */
    public function setMotifLibelle($motifLibelle)
    {
        $this->motifLibelle = $motifLibelle;

        return $this;
    }

    /**
     * Get motifLibelle
     *
     * @return string 
     */
    public function getMotifLibelle()
    {
        return $this->motifLibelle;
    }
}
