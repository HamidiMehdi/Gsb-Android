<?php

namespace MF\WebServiceBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Visiteur
 *
 * @ORM\Table(name="VISITEUR", indexes={@ORM\Index(name="FK_VISITEUR_SECTEUR", columns={"SEC_CODE"}), @ORM\Index(name="FK_VISITEUR_LABORATOIRE", columns={"LAB_CODE"})})
 * @ORM\Entity(repositoryClass="MF\WebServiceBundle\Entity\VisiteurRepository")
 */
class Visiteur
{
    /**
     * @var string
     *
     * @ORM\Column(name="VIS_MATRICULE", type="string", length=20, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $visMatricule;

    /**
     * @var string
     *
     * @ORM\Column(name="VIS_NOM", type="string", length=50, nullable=true)
     */
    private $visNom;

    /**
     * @var string
     *
     * @ORM\Column(name="VIS_PRENOM", type="string", length=100, nullable=true)
     */
    private $visPrenom;

    /**
     * @var string
     *
     * @ORM\Column(name="VIS_ADRESSE", type="string", length=100, nullable=true)
     */
    private $visAdresse;

    /**
     * @var string
     *
     * @ORM\Column(name="VIS_CP", type="string", length=10, nullable=true)
     */
    private $visCp;

    /**
     * @var string
     *
     * @ORM\Column(name="VIS_VILLE", type="string", length=60, nullable=true)
     */
    private $visVille;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="VIS_DATEEMBAUCHE", type="date", nullable=true)
     */
    private $visDateembauche;

    /**
     * @var string
     *
     * @ORM\Column(name="VIS_MDP", type="string", length=200, nullable=true)
     */
    private $visMdp;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="VIS_DERNIERCONNEXION", type="date", nullable=true)
     */
    private $visDernierconnexion;

    /**
     * @var \Laboratoire
     *
     * @ORM\ManyToOne(targetEntity="Laboratoire")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="LAB_CODE", referencedColumnName="LAB_CODE")
     * })
     */
    private $labCode;

    /**
     * @var \Secteur
     *
     * @ORM\ManyToOne(targetEntity="Secteur")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="SEC_CODE", referencedColumnName="SEC_CODE")
     * })
     */
    private $secCode;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="ActiviteCompl", mappedBy="visMatricule")
     */
    private $acNum;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->acNum = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Get visMatricule
     *
     * @return string 
     */
    public function getVisMatricule()
    {
        return $this->visMatricule;
    }

    /**
     * Set visNom
     *
     * @param string $visNom
     * @return Visiteur
     */
    public function setVisNom($visNom)
    {
        $this->visNom = $visNom;

        return $this;
    }

    /**
     * Get visNom
     *
     * @return string 
     */
    public function getVisNom()
    {
        return $this->visNom;
    }

    /**
     * Set visPrenom
     *
     * @param string $visPrenom
     * @return Visiteur
     */
    public function setVisPrenom($visPrenom)
    {
        $this->visPrenom = $visPrenom;

        return $this;
    }

    /**
     * Get visPrenom
     *
     * @return string 
     */
    public function getVisPrenom()
    {
        return $this->visPrenom;
    }

    /**
     * Set visAdresse
     *
     * @param string $visAdresse
     * @return Visiteur
     */
    public function setVisAdresse($visAdresse)
    {
        $this->visAdresse = $visAdresse;

        return $this;
    }

    /**
     * Get visAdresse
     *
     * @return string 
     */
    public function getVisAdresse()
    {
        return $this->visAdresse;
    }

    /**
     * Set visCp
     *
     * @param string $visCp
     * @return Visiteur
     */
    public function setVisCp($visCp)
    {
        $this->visCp = $visCp;

        return $this;
    }

    /**
     * Get visCp
     *
     * @return string 
     */
    public function getVisCp()
    {
        return $this->visCp;
    }

    /**
     * Set visVille
     *
     * @param string $visVille
     * @return Visiteur
     */
    public function setVisVille($visVille)
    {
        $this->visVille = $visVille;

        return $this;
    }

    /**
     * Get visVille
     *
     * @return string 
     */
    public function getVisVille()
    {
        return $this->visVille;
    }

    /**
     * Set visDateembauche
     *
     * @param \DateTime $visDateembauche
     * @return Visiteur
     */
    public function setVisDateembauche($visDateembauche)
    {
        $this->visDateembauche = $visDateembauche;

        return $this;
    }

    /**
     * Get visDateembauche
     *
     * @return \DateTime 
     */
    public function getVisDateembauche()
    {
        return $this->visDateembauche;
    }

    /**
     * Set visMdp
     *
     * @param string $visMdp
     * @return Visiteur
     */
    public function setVisMdp($visMdp)
    {
        $this->visMdp = $visMdp;

        return $this;
    }

    /**
     * Get visMdp
     *
     * @return string 
     */
    public function getVisMdp()
    {
        return $this->visMdp;
    }

    /**
     * Set visDernierconnexion
     *
     * @param \DateTime $visDernierconnexion
     * @return Visiteur
     */
    public function setVisDernierconnexion($visDernierconnexion)
    {
        $this->visDernierconnexion = $visDernierconnexion;

        return $this;
    }

    /**
     * Get visDernierconnexion
     *
     * @return \DateTime 
     */
    public function getVisDernierconnexion()
    {
        return $this->visDernierconnexion;
    }

    /**
     * Set labCode
     *
     * @param \MF\WebServiceBundle\Entity\Laboratoire $labCode
     * @return Visiteur
     */
    public function setLabCode(\MF\WebServiceBundle\Entity\Laboratoire $labCode = null)
    {
        $this->labCode = $labCode;

        return $this;
    }

    /**
     * Get labCode
     *
     * @return \MF\WebServiceBundle\Entity\Laboratoire 
     */
    public function getLabCode()
    {
        return $this->labCode;
    }

    /**
     * Set secCode
     *
     * @param \MF\WebServiceBundle\Entity\Secteur $secCode
     * @return Visiteur
     */
    public function setSecCode(\MF\WebServiceBundle\Entity\Secteur $secCode = null)
    {
        $this->secCode = $secCode;

        return $this;
    }

    /**
     * Get secCode
     *
     * @return \MF\WebServiceBundle\Entity\Secteur 
     */
    public function getSecCode()
    {
        return $this->secCode;
    }

    /**
     * Add acNum
     *
     * @param \MF\WebServiceBundle\Entity\ActiviteCompl $acNum
     * @return Visiteur
     */
    public function addAcNum(\MF\WebServiceBundle\Entity\ActiviteCompl $acNum)
    {
        $this->acNum[] = $acNum;

        return $this;
    }

    /**
     * Remove acNum
     *
     * @param \MF\WebServiceBundle\Entity\ActiviteCompl $acNum
     */
    public function removeAcNum(\MF\WebServiceBundle\Entity\ActiviteCompl $acNum)
    {
        $this->acNum->removeElement($acNum);
    }

    /**
     * Get acNum
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getAcNum()
    {
        return $this->acNum;
    }
}
