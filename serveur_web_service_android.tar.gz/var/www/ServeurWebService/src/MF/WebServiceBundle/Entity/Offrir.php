<?php

namespace MF\WebServiceBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Offrir
 *
 * @ORM\Table(name="OFFRIR", indexes={@ORM\Index(name="FK_OFFRIR_MEDICAMENT", columns={"MED_DEPOTLEGAL"})})
 * @ORM\Entity(repositoryClass="MF\WebServiceBundle\Entity\OffrirRepository")
 */
class Offrir
{
    /**
     * @var string
     *
     * @ORM\Column(name="VIS_MATRICULE", type="string", length=20, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $visMatricule;

    /**
     * @var integer
     *
     * @ORM\Column(name="RAP_NUM", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $rapNum;

    /**
     * @var integer
     *
     * @ORM\Column(name="OFF_QTE", type="integer", nullable=false)
     */
    private $offQte;

    /**
     * @var \Medicament
     *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @ORM\OneToOne(targetEntity="Medicament")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="MED_DEPOTLEGAL", referencedColumnName="MED_DEPOTLEGAL")
     * })
     */
    private $medDepotlegal;



    /**
     * Set visMatricule
     *
     * @param string $visMatricule
     * @return Offrir
     */
    public function setVisMatricule($visMatricule)
    {
        $this->visMatricule = $visMatricule;

        return $this;
    }

    /**
     * Get visMatricule
     *
     * @return string 
     */
    public function getVisMatricule()
    {
        return $this->visMatricule;
    }

    /**
     * Set rapNum
     *
     * @param integer $rapNum
     * @return Offrir
     */
    public function setRapNum($rapNum)
    {
        $this->rapNum = $rapNum;

        return $this;
    }

    /**
     * Get rapNum
     *
     * @return integer 
     */
    public function getRapNum()
    {
        return $this->rapNum;
    }

    /**
     * Set offQte
     *
     * @param integer $offQte
     * @return Offrir
     */
    public function setOffQte($offQte)
    {
        $this->offQte = $offQte;

        return $this;
    }

    /**
     * Get offQte
     *
     * @return integer 
     */
    public function getOffQte()
    {
        return $this->offQte;
    }

    /**
     * Set medDepotlegal
     *
     * @param \MF\WebServiceBundle\Entity\Medicament $medDepotlegal
     * @return Offrir
     */
    public function setMedDepotlegal(\MF\WebServiceBundle\Entity\Medicament $medDepotlegal)
    {
        $this->medDepotlegal = $medDepotlegal;

        return $this;
    }

    /**
     * Get medDepotlegal
     *
     * @return \MF\WebServiceBundle\Entity\Medicament 
     */
    public function getMedDepotlegal()
    {
        return $this->medDepotlegal;
    }
}
