<?php

namespace MF\WebServiceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MFWebServiceBundle extends Bundle
{
}
